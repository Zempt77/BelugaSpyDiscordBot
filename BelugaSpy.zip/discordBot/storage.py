import json

def Handle(ctx, action, name = None, value = None):
  with open('varStorage.json') as json_file:
    data = json.load(json_file)
  
  
  if action == 'change':
    data[str(ctx.guild.id)][name] = value

    with open('varStorage.json', 'w') as outfile:
      json.dump(data, outfile)
    return 0
  elif action == 'read':
    return data[str(ctx.guild.id)][name]
  elif action == 'setNew':

    data[str(ctx.guild.id)] = {}

    with open('varStorage.json', 'w') as outfile:
      json.dump(data, outfile)
    return 0