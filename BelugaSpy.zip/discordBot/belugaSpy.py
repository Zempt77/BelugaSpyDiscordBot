import discord
import os
import time
import asyncio
import storage
from discord.utils import get
from discord.utils import find
from discord.ext import commands
from discord import Color
import random
import requests
import json

client = commands.Bot(command_prefix='!')

admins = [372124383088476160]

conn4Challenged = {}
conn4GameStorage = {}

sjParty = []
slapjackChan = 0
sjdeck = 0
sjdeckID = 0
sjTurn = -1
sjIsFlipped = False
isJack = False

def splitChar(string):
    return [char for char in string]

def ifListInDict(dictA, subject):
    for i in dictA.values():
        if type(i) == list:
            return subject in i



def generateConn4String(boardList):
    conn4StringList = []
    iterator = 0
    # creates a list of strings, set depending on the value of the element in boardList
    for i in range(6):
        for q in boardList:
            if type(q) == list:
                if q[i] == 0:
                    conn4StringList.append(':white_circle:')
                elif q[i] == 1:
                    conn4StringList.append(':red_circle:')
                elif q[i] == 2:
                    conn4StringList.append(':yellow_circle:')
        conn4StringList.append('\n')
    # joins the elements and returns a single string        
    return "".join(conn4StringList)

def conn4Drop(ctx, column, piece):
    columnList = conn4GameStorage[ctx][column]
    # iterates through columnList bottom to top
    for i in range(len(columnList) - 1, -1, -1):
        if columnList[i] == 0:
            conn4GameStorage[ctx][column][i] = piece
            return 1
    return 0

def conn4WinDetect(board):
    # horizontal detection
    for x in range(len(board) - 5):
        for y in range(len(board[0])):
            tile = board[x][y]
            if board[x + 1][y] == tile and board[x + 2][y] == tile and board[x + 3][y] == tile and tile != 0:
                return tile
    # vertical detection
    for x in range(len(board) - 2):
        for y in range(len(board[0]) - 3):
            tile = board[x][y]
            if board[x][y + 1] == tile and board[x][y + 2] and board[x][y + 3] == tile and tile != 0:
                return tile
    # diagonal detection
    for x in range(len(board) - 5):
        for y in range(len(board[0]) - 3):
            tile = board[x][y]
            if board[x + 1][y + 1] == tile and board[x + 2][y + 2] == tile and board[x + 3][y + 3] == tile and tile != 0:
                return tile
    # other diagonal detection(other direction)
    for x in range(len(board) - 3):
        for y in range(3, len(board[0])):
            tile = board[x][y]
            if board[x][y] == tile and board[x+1][y-1] == tile and board[x+2][y-2] == tile and board[x+3][y-3] == tile:
                return tile
    return False



def columnIsClear(column):
    if column[0] > 0:
        return False
    else:
        return True


def belugaMath(string):
    # creates a list of each number and operand
    splitString = string.split()
    splitString.pop(0)
    # converts all numbers into float
    for i in range(len(splitString)):
        try:
            splitString[i] = float(splitString[i])
        except:
            continue
    # tests if each element is a operand, if so it executes that operand
    while len(splitString) > 1:
        for i in range(len(splitString)):
            if splitString[i] == '^':
                splitString[i] = splitString[i - 1] ** splitString[i + 1]
                splitString.pop(i - 1)
                splitString.pop(i)
                break
        for i in range(len(splitString)):
            if splitString[i] == '*':
                splitString[i] = splitString[i - 1] * splitString[i + 1]
                splitString.pop(i - 1)
                splitString.pop(i)
                break
        for i in range(len(splitString)):
            if splitString[i] == '/':
                splitString[i] = splitString[i - 1] / splitString[i + 1]
                splitString.pop(i - 1)
                splitString.pop(i)
                break
        for i in range(len(splitString)):
            if splitString[i] == '+':
                splitString[i] = splitString[i - 1] + splitString[i + 1]
                splitString.pop(i - 1)
                splitString.pop(i)
                break
        for i in range(len(splitString)):
            if splitString[i] == '-':
                splitString[i] = splitString[i - 1] - splitString[i + 1]
                splitString.pop(i - 1)
                splitString.pop(i)
                break
    return splitString[0]

def conn4TieDetect(board):
    if board[0][0] > 0 and board[1][0] > 0 and board[2][0] > 0 and board[3][0] > 0 and board[4][0] > 0 and board[5][0] > 0 and board[6][0] > 0:
        return True
    else:
        return False

async def slapJackStart(guild):
    global slapjackChan
    global sjTurn
    global sjdeck
    global sjdeckID
    # creates channel called 'slapjack'
    slapjackChan = await guild.create_text_channel(name = 'slapjack')
    players = len(sjParty)
    dealer = sjParty[0]
    sjTurn = 0

    # sends request to deckorcardsapi.com to get shuffled deck
    try:
        sjdeck = requests.get('https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1').json()
        sjdeckID = sjdeck['deck_id']
    except:
        print('error')
    # splits deck between players
    while sjdeck['remaining'] > 0:
        for i in range(players):
            # draws card from deck
            try:
                tempCard = requests.get('https://deckofcardsapi.com/api/deck/' + sjdeckID + '/draw/?count=1').json()
                print(tempCard)
            except:
                break
            # moves drawn card to players pile
            sjdeckID = tempCard['deck_id']
            sjdeck = requests.get('https://deckofcardsapi.com/api/deck/' + sjdeckID + '/pile/' + str(i) + '/add/?cards=' + tempCard['cards'][0]['code']).json()
            if tempCard['remaining'] == 0:
                break


async def slapJackEnd(guild):
    global slapjackChanID
    await slapjackChan.delete()
    sjParty.clear()

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    await client.change_presence(activity=discord.Game(name="with the Russians"))

@client.event
async def on_guild_join(guild):
    # greets server
    general = find(lambda x: x.name == 'general',  guild.text_channels)
    if general and general.permissions_for(guild.me).send_messages:
        await general.send('Hello {}!'.format(guild.name))
    # sets default prefix to beluga!
    storage.Handle(general, 'setNew')
    storage.Handle(general, 'change', 'prefix', 'beluga!')
    await general.send('default prefix is beluga!<command>')


@client.event
async def on_message(message):
    global admins
    global sjTurn
    global sjParty
    global slapjackChan
    global sjdeck
    global sjdeckID
    global sjIsFlipped
    global isJack
    iterator = 0
    
    # checks if the message is a DM
    if message.guild == None:
        isDM = True
    else:
        isDM = False
    
    # all code in this if block only runs if the message is not a DM
    if isDM != True:
        # sets local variable 'prefix' to server specific variable prefix, stored in varStorage.json
        prefix = storage.Handle(message, 'read', 'prefix')
        
        # makes sure that the message was not from itself or that it starts with the set prefix
        if message.author == client.user:
            return

        if (message.author.id != 372124383088476160 and message.author.id != 814194887104528395) and message.content.startswith(prefix):
            await message.channel.send('Beluga currently down for development!')
            return

        # prefix change
        if message.content.startswith(prefix + 'prefixChange') and message.author.id in admins:
            temp = message.content.split()
            storage.Handle(message, 'change', 'prefix', temp[-1])
            
            await message.channel.send('Prefix successfully changed to: ' + storage.Handle(message, 'read', 'prefix'))

        # help embed
        if message.content.startswith(prefix + 'help'):
            helpEmbed = discord.Embed(
                title = 'Help Page',
                description = 'A list of general commands for the Beluga Spy Bot',
                colour=Color.blue()
            )

            helpEmbed.add_field(name='General Commands', value='prefixChange <new prefix> - Changes the prefix to <new prefix>')
            helpEmbed.add_field(name='Game Commands', value='conn4 <mention> - Challenges the mentioned player to a Connect 4 match \nconn4 accept - Accepts a Connect 4 challenge', inline=False)
            helpEmbed.add_field(name='Useful Commands', value='rand <limit> - generates a number between 0 and <limit> \nmath <expression> - solves <expression>, put a space between each character e.x. 5 * 5 / 5', inline=False)

            await message.channel.send(embed=helpEmbed)
        
        # connect 4 challenge
        if message.content.startswith(prefix + 'conn4') and not message.content == prefix + 'conn4 accept' and not message.content == prefix + 'conn4 decline':
            # if no one is mentioned in challenge
            if len(message.mentions) <= 0:
                await message.channel.send('Please mention someone to play Connect 4!')
                return
            # if more than one person is mentioned
            elif len(message.mentions) > 1:
                await message.channel.send('Please only mention one person to play Connect 4!')
                return
            # if user mentiones themselves
            elif message.mentions[0].id == message.author.id:
                await message.channel.send("You can't challenge yourself dummy!")
                return
            # if user mentions bot
            elif message.mentions[0].bot:
                await message.channel.send("You cannot challenge bots silly!")
                return
            # challenge success
            else:
                await message.channel.send('Hey <@' + str(message.mentions[0].id) + '>! <@' + str(message.author.id) + "> challenged you to a Connect 4 match! You have 5 minutes to accept, say '" + prefix + "conn4 accept' to accept!")
                conn4Challenged[str(message.mentions[0].id)] = message.author.id
                await asyncio.sleep(300)
                if message.mentions[0].id in conn4Challenged:
                    await message.channel.send('<@' + str(message.mentions[0].id) + '> did not respond, Connect 4 game cancelled')
                    conn4Challenged.pop(str(message.mentions[0].id))
                else:
                    return

        # connect 4 challenge accept and intialization
        if message.content == prefix + 'conn4 accept':
            if str(message.author.id) not in conn4Challenged:
                await message.channel.send('You have not been challenged, or the challenge has expired.')
                return
            else:
                await message.channel.send('Challenge Accepted! <@' + str(message.author.id) + '>, <@' + str(conn4Challenged[str(message.author.id)]) + '> the game has begun!')
                # creates blank grid
                conn4GameStorage[str(message.author.id)] = []
                # initializing grid to zeros(empty slots)
                for i in range(7):
                    conn4GameStorage[str(message.author.id)].append([])
                    for q in range(6):
                        conn4GameStorage[str(message.author.id)][i].append(0)
                #adds a 0 to denote turn
                conn4GameStorage[str(message.author.id)].append(0)
                #adds opponent id to list
                conn4GameStorage[str(message.author.id)].append(conn4Challenged[str(message.author.id)])
                #removes entry from challenged list
                conn4Challenged.pop(str(message.author.id))
                conn4Embed = discord.Embed(title = '**Current Connect 4 Game**', color = 0xff0000)
                conn4Embed.add_field(name = 'Current Board', value = generateConn4String(conn4GameStorage[str(message.author.id)]) + '\n**It is your turn**')
                conn4Embed.add_field(name = 'Moves', value = '**c1** - Drops in column 1 \n**c2** - Drops in column 2 \n**c3** - Drops in column 3 \n**c4** - Drops in column 4 \n**c5** - Drops in column 5 \n**c6** - Drops in column 6 \n**c7** - Drops in column 7', inline = False)


                await message.author.send(embed=conn4Embed)
        
        # connect 4 decline
        if message.content == prefix + 'conn4 decline':
            if str(message.author.id) not in conn4Challenged:
                await message.channel.send('You have not been challenged, or the challenge has expired.')
                return
            else:
                conn4Challenged.remove(str(message.author.id))
                await message.channel.send('Connect 4 challenge declined')
        # random number generator
        if message.content.startswith(prefix + 'rand'):
            # makes sure that the element after rand is a number
            try:
                limit = int(message.content.split()[1])
            except:
                await message.channel.send('Please insert a number!')
                return
            # creates an Embed with the result
            randEmbed = discord.Embed()
            randEmbed.add_field(name = 'Random Number Generator', value = 'The random number is: ' + str(random.randint(0, limit)))
            await message.channel.send(embed=randEmbed)

        # belugaMath
        if message.content.startswith(prefix + 'math'):
            mathEmbed = discord.Embed(colour=Color.blue())
            mathEmbed.add_field(name = 'Math Evaluation', value = '**The answer is: **' + str(belugaMath(message.content)))

            await message.channel.send(embed=mathEmbed)

        # makes fun of bakirs music lol
        if ('youtube.com/watch' in message.content or 'youtu.be' in message.content) and message.author == await client.fetch_user(742822600605958165):
            embed = discord.Embed()
            embed.add_field(name='i dont care', value='i dont care about your music bakir')
            await message.channel.send(embed=embed)
            
                
    # code here only runs if the message is a DM
    if isDM == True:
        # make sure that the DM is not from itself
        if message.author == client.user:
            return
        # clears all games DEV USE ONLY!!!!!!
        if message.content == 'cclear' and message.author.id in admins:
            conn4GameStorage.clear()

        # connect 4 game main
        if splitChar(message.content)[0] == 'c':
            # make sure that the player is actually in a game
            if str(message.author.id) in conn4GameStorage.keys() or ifListInDict(conn4GameStorage, message.author.id):
                # initializes player variable to -1
                player = -1
                # sets player based on who challenged who
                if str(message.author.id) in conn4GameStorage:
                    player = 0
                    gameID = message.author.id
                else:
                    player = 1
                    for i in conn4GameStorage.values():
                        try:
                            i.index(message.author.id)
                        except:
                            continue
                    # sets gameID for future use
                    gameID = list(conn4GameStorage.keys())[list(conn4GameStorage.values()).index(i)]
                # checks if it is the players turn
                if player == conn4GameStorage[str(gameID)][-2]:
                    # tries to seperate the message by character such: 'c', '4' if exception, then tells the user to input a number after c
                    try:
                        column = int(splitChar(message.content)[1])
                    except:
                        await message.author.send('Please put a number after c')
                        return
                    # runs drop function, 'dropping' the piece into the board also making sure that the column is not full
                    if conn4Drop(str(gameID), column - 1, player + 1) == 0:
                        await message.author.send('That column is full!')

                    # generated the embed conataining the board and current moves
                    conn4Embed = discord.Embed(title = 'Current Connect 4 Game')
                    conn4Embed.add_field(name = 'Current Board', value = generateConn4String(conn4GameStorage[str(gameID)]) + "**It is the other player's turn**")
                    conn4Embed.add_field(name = 'Moves', value = '**c1** - Drops in column 1 \n**c2** - Drops in column 2 \n**c3** - Drops in column 3 \n**c4** - Drops in column 4 \n**c5** - Drops in column 5 \n**c6** - Drops in column 6 \n**c7** - Drops in column 7', inline = False)
                    await message.author.send(embed=conn4Embed)

                    # sends embed to other player
                    if player == 0:
                        conn4Embed = discord.Embed(title = 'Current Connect 4 Game', color = 0xf1c40f)
                        conn4Embed.add_field(name = 'Current Board', value = generateConn4String(conn4GameStorage[str(gameID)]) + "**It is your turn**")
                        conn4Embed.add_field(name = 'Moves', value = '**c1** - Drops in column 1 \n**c2** - Drops in column 2 \n**c3** - Drops in column 3 \n**c4** - Drops in column 4 \n**c5** - Drops in column 5 \n**c6** - Drops in column 6 \n**c7** - Drops in column 7', inline = False)

                        otherPlayer = await client.fetch_user(conn4GameStorage[str(gameID)][-1])
                        await otherPlayer.send(embed=conn4Embed)
                        
                        conn4GameStorage[str(gameID)][-2] = 1
                    else:
                        conn4Embed = discord.Embed(title = 'Current Connect 4 Game', color = 0xff0000)
                        conn4Embed.add_field(name = 'Current Board', value = generateConn4String(conn4GameStorage[str(gameID)]) + "**It is your turn**")
                        conn4Embed.add_field(name = 'Moves', value = '**c1** - Drops in column 1 \n**c2** - Drops in column 2 \n**c3** - Drops in column 3 \n**c4** - Drops in column 4 \n**c5** - Drops in column 5 \n**c6** - Drops in column 6 \n**c7** - Drops in column 7', inline = False)

                        otherPlayer = await client.fetch_user(gameID)
                        await otherPlayer.send(embed=conn4Embed)

                        conn4GameStorage[str(gameID)][-2] = 0
                        
                    # sends both players a win embed if one player wins
                    if conn4WinDetect(conn4GameStorage[str(gameID)]) == 1:
                        conn4Embed = discord.Embed(title = 'Game Finished', description = str(await client.fetch_user(gameID)) + ' has won the game.')
                        await message.author.send(embed=conn4Embed)
                        await otherPlayer.send(embed=conn4Embed)
                        conn4GameStorage.pop(str(gameID))
                    elif conn4WinDetect(conn4GameStorage[str(gameID)]) == 2:
                        conn4Embed = discord.Embed(title = 'Game Finished', decription = str(await client.fetch_user(conn4GameStorage[str(gameID)][-1])) + ' has won the game.')
                        await message.author.send(embed=conn4Embed)
                        await otherPlayer.send(embed=conn4Embed)
                        conn4GameStorage.pop(str(gameID))
                    

                    # if game ends in a tie, send tie embed to both players
                    if conn4TieDetect(conn4GameStorage[str(gameID)]) == True:
                        conn4Embed = discord.Embed(title = 'Game Finished', description = 'It was a tie!')
                        await message.author.send(embed=conn4Embed)
                        await otherPlayer.send(embed=conn4Embed)
                        conn4GameStorage.pop(str(gameID))
                else:
                    await message.author.send('**It is not your turn!**')
                    
            else:
                await message.author.send('You are not currently in a Connect 4 Game!')

client.run('<insert bot token>')